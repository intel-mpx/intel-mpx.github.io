Put these two files into the `TestScripts` directory inside the Agner Fog's testing framework. The framework itself can be found [here](http://www.agner.org/optimize/testp.zip). The instructions for running the script can be found in the framework documentation.

`install.sh` is just a helper for framework installation, you may ignore it.
